@protocol UADSDictionaryConvertible <NSObject>
- (NSDictionary *)dictionary;
@end
